package com.table;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TableBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
