package com.example.userconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
