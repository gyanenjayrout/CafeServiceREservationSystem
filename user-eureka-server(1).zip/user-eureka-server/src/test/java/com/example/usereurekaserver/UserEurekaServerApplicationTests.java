package com.example.usereurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
